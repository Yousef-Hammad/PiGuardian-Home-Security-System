## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Bisher Abou-Alwan
### Week: 9 (March 13 - March 19)
___
1. **How many hours did you spend on the project this week? (0-10)**
   - 5 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Built Motor functionality, 2h
   2. 2nd item: Finished Technical Memo Draft, 3h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Successfully incorporated motor into system
  - Finished the technical memo and its feedback

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Very good, our progress is on a great run.

5. ***What are you planning to do next week***? _(give specific goals)_
  - Build doorbell feature
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
