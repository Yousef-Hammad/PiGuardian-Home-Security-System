Weekly Individual Project Update Report

Group number: L2-G6

Student name: Hamdiata Diakite

Week: 9 (March 13 - March 19)

How many hours did you spend on the project this week? (0-10) 4 hours

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Top item: Tech memo draft, 2h
2nd item: Unit test demo, 2h

What did you accomplish this week? (Be specific)

This week I started and finished the tech memo draft. I aslo started and mostly completed my script for the unit test demo.


How do you feel about your progress? (brief, free-form reflection)
I think my progress has been good so far.


What are you planning to do next week? (give specific goals)
Finsih the tech memo, and prepare for the final demo


Is anything blocking you that you need from others? (What do you need from whom)
No
