## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Alizee Drolet
### Week: 12 (April 03 - April 09)
___
1. **How many hours did you spend on the project this week? (0-10)**
   3 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Final report, 3h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Completed final report

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress have been up to date
  - We are done with our project!!
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - N/A
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
