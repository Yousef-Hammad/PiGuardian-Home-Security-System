## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Hamdiata Diakite
### Week: 12 (April 03 - April 09)
___
1. **How many hours did you spend on the project this week? (0-10)**
   5 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Final Demo prep 3h
   3. 2nd item: Final report 2h
   
3. ***What did you accomplish this week?*** _(Be specific)_
    Made final touches for the final demo
    Worked on the final project report.

5. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress has been up-to-date.
  
    
5. ***What are you planning to do next week***? _(give specific goals)_
  N/A last week
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
