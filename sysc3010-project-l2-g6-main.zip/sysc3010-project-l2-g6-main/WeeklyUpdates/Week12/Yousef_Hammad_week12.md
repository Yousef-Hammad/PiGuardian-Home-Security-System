## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Yousef Hammad
### Week: 12 (April 03 - April 09)
___
1. **How many hours did you spend on the project this week? (0-10)**
   3 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Final Demo prep 2h
   3. 2nd item: Final report 1h
   
3. ***What did you accomplish this week?*** _(Be specific)_
    - Worked with my team to prepare for the final demo
    - worked on the final report

5. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - great, nothing to complain about
  
    
5. ***What are you planning to do next week***? _(give specific goals)_
   - N/A
    
7. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
