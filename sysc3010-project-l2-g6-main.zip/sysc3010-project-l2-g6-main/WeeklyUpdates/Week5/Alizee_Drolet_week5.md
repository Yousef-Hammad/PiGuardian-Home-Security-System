## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Alizee Drolet
### Week: 5 (January 07 - February 13)
___
1. **How many hours did you spend on the project this week? (0-10)**
   4 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Final proposal, 3h
   2. 2nd item: Researched and planned the hardware components (proximity sensor, light sensor, etc) for my part of the project, 1h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Completed our proposal (my part includes sections 1-1.3 and part of the use cases/hardware components)
  - Found ways to control the lighting using RPi and a photoresistor. I can make a voltage divider circuit with a photoresistor to output a low/high voltage to the RPi to determine whether it is day or night.
  - Wrote code to detect a person using Pi Camera

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress has been up-to-date. I am more clear with what my goals are with the project, and once we order our components, I can start implementing the actual feature.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Finalize our hardware list by Monday
  - Start helping Yousef with his GUI with the rest of the group (maybe use figma)
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
