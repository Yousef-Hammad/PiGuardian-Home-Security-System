## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Yousef Hammad
### Week: 5 (February 7 - February 13)
___
1. **How many hours did you spend on the project this week? (0-10)**
   3 hours

2. **Give a rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Project Proposal Final version, 2h
   2. 2nd item: did some more research on the GUI part of our project, 1h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Completed my part of the project proposal (sections 1.4, 3.1, 3.1.1, and 4)
  - Read student feedback from feedback fruits and implemented changes on the final project proposal document.

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - I am fine with my teams' progress, everyone is on top of their stuff.
 
5. ***What are you planning to do next week***? _(give specific goals)_
  - Start actually implementing a simple GUI on my own Pi. Everything I have done so far was research, now I want to have something simple going.
  - Try to meet with Hamdiata (if time allows) to discuss how we are going to be passing information between the raspberry pis. 
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
