## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Yousef Hammad
### Week: 10 (March 20 - March 26)
___
1. **How many hours did you spend on the project this week? (0-10)**
   6 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Tech memo, 2h
   2. 2nd item: Unit test code for software test, 2h
   3. 3rd item: GUI screen and API endpoints, 2h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Finished the final copy for my technical memo
  - Finished writing all my code for my unit test
  - Continued work for my GUI screens and API endpoints

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - I feel great. I'm up to date with my stuff
  - Still have a lot of GUI screens left to complete
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Figure out how to extract video recordings from the firebase and display them inside the GUI
  - Help the other team members with the final integration 
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
