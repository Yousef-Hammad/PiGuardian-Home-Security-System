Weekly Individual Project Update Report

Group number: L2-G6

Student name: Hamdiata Diakite

Week: 10 (March 20 - March 26)

How many hours did you spend on the project this week? (0-10) 5

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Top item: Working on code
2nd item: Tech memo 


What did you accomplish this week? (Be specific)

This week I wroked on code that allows us to put video in the cloud database.


How do you feel about your progress? (brief, free-form reflection)
I think my progress has been good so far.


What are you planning to do next week? (give specific goals)
Record the final video and final project integration.


Is anything blocking you that you need from others? (What do you need from whom)
No

