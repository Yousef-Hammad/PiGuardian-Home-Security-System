## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Yousef Hammad
### Week: 11 (March 27 - April 02)
___
1. **How many hours did you spend on the project this week? (0-10)**
   7 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Project video, 3h
   3. 2nd item: finished entire web GUI and made sure it worked perfectly with the rest of the raspberry pis, 4h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Finished recording the project video with my team
  - Completed all the different screens for the GUI.

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress has been perfect so far. i finished all my parts, same goes with my team members.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Start working on the final report
  - Practice final demo
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
