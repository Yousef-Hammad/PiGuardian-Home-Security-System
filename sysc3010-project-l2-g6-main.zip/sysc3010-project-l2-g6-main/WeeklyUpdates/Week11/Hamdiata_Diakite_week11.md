## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Alizee Drolet
### Week: 11 (March 27 - April 02)
___
1. **How many hours did you spend on the project this week? (0-10)**
   8 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   Final project integration 5 hours
   Project Video 3 hours
   
4. ***What did you accomplish this week?*** _(Be specific)_
  End-End integration of the entire systems was completed. The project video was also filmed. 

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  Our progress in on pace and the project is nearly complete. The remaning task our the final demo and the project report.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  Final demo practice and finish the final project report.
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
