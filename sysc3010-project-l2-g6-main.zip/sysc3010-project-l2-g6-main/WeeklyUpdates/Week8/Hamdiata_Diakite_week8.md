
Weekly Individual Project Update Report

Group number: L2-G6

Student name: Hamdiata Diakite

Week: 8 (March 6 - March 12)

How many hours did you spend on the project this week? (0-10) 8

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

 End-End Demo script (5)
 Metting (3)

 
What did you accomplish this week? (Be specific) 

This past week I completed and presented my script for the end-end demo. I also met with me team in the library to prepare for the end-end demo

How do you feel about your progress? (brief, free-form reflection) 

I think my progress has been solid. I am responsible for the backend and database for the project and so far we have a flask server running.
There is still some hicups and bugs I need to fix but overall I think I am on the right track.

What are you planning to do next week? (give specific goals) Finalize design document. 

Next week I hope to fix the bugs I metioned aboved and I aslo need to complete and present my unit test demo scrip.

Is anything blocking you that you need from others? (What do you need from whom)

No
