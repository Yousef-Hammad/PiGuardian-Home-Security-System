Weekly Individual Project Update Report

Group number: L2-G6

Student name: Bisher Abou-Alwan

Week: 1 (January 23 - January 30)

How many hours did you spend on the project this week? 4

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Top item: Pre-proposal submission in a meeting, 1.5h 
2nd item: Dividing roles up for proposal in a meeting, 0.5h 
3rd item: Narrowing down and choosing our project in class, 0.5h 
4th item: Brainstroming project features after class, 0.5h

What did you accomplish this week?

We chose our project, learned about cloud databases to use in our project throught lab 3, completed and submitted our pre-proposal, and we each have identified a clear role to play in the proposal.

How do you feel about your progress? (brief, free-form reflection)

Stady and great, we keep adding onto what we previously built in knowledge and ideas, allowing us to achieve our weekly goals and march closer to project completion.

What are you planning to do next week? (give specific goals)

Finish the draft project proposal and research project components

Is anything blocking you that you need from others? (What do you need from whom)

No
