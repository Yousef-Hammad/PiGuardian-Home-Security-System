## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: 101217858
### Week:3 (January 23 - January 30)
___
1. **How many hours did you spend on the project this week? (0-10)**
   - 3.5 total hours

3. **Give rough breakdown of hours spent on 1-3 of the following:***
   1. 1h: Met with the team after class to decide on the final project and discuss the pros/cons of it
   2. 2h: I met with my team to finish up the pre-proposal document and divide up tasks for the final proposal document. 
   3. 0.5h: did some research for my specific part of the project (setting up the GUI)
      
4. ***What did you accomplish this week?***
  - Decided on the final group project our team is going with (home security system)
  - Discussed in detail the specifics of the project (what each RPi will do)
  - Finished the pre-proposal document, and delegated tasks for the final proposal document
  - Did some research for my specific part in the project (setting up the GUI)

6. ***How do you feel about your progress?***
  - We did really well in terms of progress. Our team not only finished what was required of us for the given week, but we also planned what were going to do for the next following weeks.

8. ***What are you planning to do next week***?
  - Finish up the final project proposal document
    
9. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - Not as of right now

