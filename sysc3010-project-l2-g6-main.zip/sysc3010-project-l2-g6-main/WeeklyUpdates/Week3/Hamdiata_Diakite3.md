This week about 5 hours and 30 minutes of work has been put towards the project. Lab 3, witch touch everything from the sense hat display,
to Firebase and basic GUI development took arounf 4 hours to complete. Another 1 hour and 30 minutes was spend working with the team to 
complete the 1 page pre proposal and divide up the work for the upcoming project proposal document. Futhermore, the project was futher fleshed out. Next week I will work on lab 4 and the project proposal. Nothing is blocking me/us at this moment 
