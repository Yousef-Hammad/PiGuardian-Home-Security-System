## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Hamdiata Diakite
### Week: 7 (February 27 - March 5)
___
1. **How many hours did you spend on the project this week? (0-10)**
   8 

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. sofware implementation (4 hours)
   2. 2nd item: Design document draft (2 hour)
   3. 3rd item End-End Demo script (2)
   
3. ***What did you accomplish this week?*** _(Be specific)_
This week I started implementing the route.py file. This file is where the API endpoints are defined. The GUI will be using this file to make HTTP request to the Firestore. In addition I started working on my script for the end to end demo. The script will prove that HTTP communication works properly.

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
So far are progress had been good we are on schedule. It is important we do not fall behind, time window is tight.
    
5. ***What are you planning to do next week***? _(give specific goals)_
Finalize design document.
Start doing reaserch on how to do automated testing for the unit test demo.

7. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
