## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Alizee Drolet
### Week: 6 (February 14 - February 20)
___
1. **How many hours did you spend on the project this week? (0-10)**
   3 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Finalized component ordering sheet, 1h
   2. 2nd item: Started writing pseudo-code for the hardware components, 2h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Finalized component ordering sheet, because our previous one had a component that did not match the specs that we needed
  - Researched and wrote pseudo-code for the light controlling system and the proximity sensor

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress has been up-to-date. There will be more work done once I get access to the hardware components.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Refine the code for person detection
  - Help Yousef with his GUI with the rest of the group (maybe use figma)
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
