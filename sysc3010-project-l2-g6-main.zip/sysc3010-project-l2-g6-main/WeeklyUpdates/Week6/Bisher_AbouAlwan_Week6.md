# Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Bisher Abou-Alwan
### Week: 6 (February 14 - February 20)
___
1. **How many hours did you spend on the project this week? (0-10)**
   - 7 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Building RPI Face Recogntion system (5h)
   2. 2nd item: Understand how to connect my face recognition info to cloud DB (2h)
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Built a functional model of face recognition using my RPI
  - Researched and wrote pseudo-code for the connection to Firebase DB

4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Progress is great as long as we keep up the current pace, we will likely need to add more hours on this project soon.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Optimize and improve code 
  - Successfully communicate with Firebase
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
