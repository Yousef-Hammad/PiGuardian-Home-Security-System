Weekly Individual Project Update Report

Group number: L2-G6

Student name: Hamdiata Diakite

Week: 6

How many hours did you spend on the project this week? (0-10) 3

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Set up the intial directory structure for the project ans started working on the backend




How do you feel about your progress? (brief, free-form reflection)
I feel good about my progress, I have a much better understasding of the wrk needed to complete the project.

What are you planning to do next week? (give specific goals)
Hopefully have a functional backend up an running.


Is anything blocking you that you need from others? (What do you need from whom)
No
