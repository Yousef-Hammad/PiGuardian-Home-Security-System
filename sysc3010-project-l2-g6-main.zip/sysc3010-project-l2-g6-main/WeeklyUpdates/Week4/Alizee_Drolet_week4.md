## Weekly Individual Project Update Report
### Group number: L2-G6
### Student name: Alizee Drolet
### Week: 4 (January 31 - February 06)
___
1. **How many hours did you spend on the project this week? (0-10)**
   5 hours

2. **Give rough breakdown of hours spent on 1-3 of the following:***
   (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)
   1. Top item: Proposal draft, 3h
   2. 2nd item: Researched and planned which components (proximity sensor, light sensor, etc) to buy for my part of the project, 2h
   
3. ***What did you accomplish this week?*** _(Be specific)_
  - Completed our proposal draft, speficially the introductiion and part of the use-cases.
  - Researched and prepared my component list and how to connect to the RPi
4. ***How do you feel about your progress?*** _(brief, free-form reflection)_
  - Our progress has been up-to-date. I am more clear with what my goals are with the project, and once we order our components, I can start implementing the actual feature.
    
5. ***What are you planning to do next week***? _(give specific goals)_
  - Fix our proposal based on the feedback we get
  - Start helping Yousef with his GUI with the rest of the group (maybe next week, maybe later)
    
6. ***Is anything blocking you that you need from others?*** _(What do you need from whom)_
  - No
