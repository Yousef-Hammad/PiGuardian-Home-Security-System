Weekly Individual Project Update Report

Group number: L2-G6

Student name: Bisher Abou-Alwan

Week: 4 (January 31 - February 6)

How many hours did you spend on the project this week? 5

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Top item: Proposal draft, 3h
2nd item: Researching Facial Detection, 2h

What did you accomplish this week?

We completed our draft proposal and researched informaion on our components

How do you feel about your progress? (brief, free-form reflection)

Stady and great, we keep adding onto what we previously built in knowledge and ideas, allowing us to achieve our weekly goals and march closer to project completion.

What are you planning to do next week? (give specific goals)

Understand and implement the feedback from the draft proposal in order to cpmplete the final proposal

Is anything blocking you that you need from others? (What do you need from whom)

No
