Weekly Individual Project Update Report

Group number: L2-G6

Student name: Hamdiata Diakite

Week: 4 (January 31 - February 6)

How many hours did you spend on the project this week? (0-10):
  5

Give rough breakdown of hours spent on 1-3 of the following:* (meetings, information gathering, design, research, brainstorming, evaluating options, prototyping options, writing/documenting, refactoring, testing, software implementation, hardware implementation)

Top item: Writting Documenting: 3
2nd item: research, 2
What did you accomplish this week? (Be specific)

This week, I learned how to create an entity relationship diagram (ERD). This will be used to create the database schema that will be put into the project proposal. I also worked on the project milestone table and the project timeline.

How do you feel about your progress? 

I felt like a made good progress with the ERD. I do know that the database schema has to be approved upon. For example I know that a extra table will be needed for the facial recognition element of the project. The overall schema could also look cleaner.

What are you planning to do next week? 

Next week I plan on finalizing the database schema. I also would like to do more reaserch on how relational databases are implemented. I also will need to do more reaserch with REST API and socket communication. I am primarily responsible for the backend of the system. And I do not have much experience with either. I will be using socket communication in other course (SYSC 3303) so I hope this will allow me to learn in parallel.

Is anything blocking you that you need from others? (What do you need from whom)

The SD card reader of my Pi seems broken. This causes the the Pi to be stuck in bootloader. 
I contacted SCE tech services and they told me to hold on to the Pi while they evaluate options. This will prevent me from doing any work on the Pi.

